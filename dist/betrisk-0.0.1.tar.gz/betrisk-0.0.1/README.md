# CapitalAllocator
Python code to manage capital allocation
